$(function() {
    $.ajaxSetup({
        cache: false
    });
});
